﻿namespace Host
{
    public class ClientSelector
    {
        public string SelectedClient = "";
    }
}
