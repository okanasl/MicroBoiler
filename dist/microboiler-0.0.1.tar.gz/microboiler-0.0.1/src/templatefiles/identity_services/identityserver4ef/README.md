# START UPPER
<ul>
    <li>IdentityServer4 (Entity Framework - .Net Core)</li>
    <li>Admin API for user management (.Net Core)</li>
    <li> Admin Client (Angular)</li>
    <li> Client App (Universal) </li>
</ul>


