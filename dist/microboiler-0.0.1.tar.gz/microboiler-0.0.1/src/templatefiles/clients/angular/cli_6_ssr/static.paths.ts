export const ROUTES = [
  '/',
  '/lazy',
  '/lazy/nested'
];
