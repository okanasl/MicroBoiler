class JavaScript:
    pass